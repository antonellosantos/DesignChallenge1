package Challenge2; 

public class Circle extends Shape{
	public void drawCircle(int x) {
		System.out.println("This is a circle");
	}
}
