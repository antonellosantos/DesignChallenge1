package Challenge2; 
public class Triangle extends Shape{
	public void drawTriangle(int x) {
		System.out.println("This is a triangle");
	}
}
