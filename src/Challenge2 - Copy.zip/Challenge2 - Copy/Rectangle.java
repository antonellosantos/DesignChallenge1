package Challenge2; 
public class Rectangle extends Shape {
	public void drawRectangle(int x) {
		System.out.println("This is a rectangle");
	}
}
