package Challenge2; 
public class Star extends Shape {
	public void drawStar(int x) {
		System.out.println("This is a star");
	}
}
