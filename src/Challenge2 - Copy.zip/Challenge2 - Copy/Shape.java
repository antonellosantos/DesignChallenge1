package Challenge2;

public class Shape {
	int m_type;
}
